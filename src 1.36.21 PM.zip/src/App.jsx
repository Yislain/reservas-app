import { BrowserRouter, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { supabase } from './lib/supabase';
import Booking from './pages/Booking';
import Admin from './pages/Admin';
import Login from './pages/Login';
import ResetPassword from './pages/ResetPassword';
import UpdatePassword from './pages/UpdatePassword';

// Componente para escuchar cambios de sesión globalmente (Multisesiones)
function AuthListener() {
  const navigate = useNavigate();

  useEffect(() => {
    // Suscribirse a los cambios de autenticación en tiempo real
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log("Cambio de sesión detectado:", event);
      
      // Si el usuario cierra sesión o el token expira, lo expulsamos de cualquier pestaña
      if (event === 'SIGNED_OUT') {
        navigate('/login');
      }
    });

    // Limpiar la suscripción cuando el componente se desmonta
    return () => subscription.unsubscribe();
  }, [navigate]);

  return null; // Este componente vigila en silencio, no renderiza nada visual
}

function App() {
  return (
    <BrowserRouter>
      {/* Activamos el escuchador de sesiones dentro del Router para poder usar navigate */}
      <AuthListener />

      <div className="min-h-screen text-white font-sans selection:bg-blue-500/30">
        
        {/* Navbar Flotante (Glassmorphism) */}
        <nav className="fixed top-0 left-0 right-0 z-50 bg-zinc-950/70 backdrop-blur-lg border-b border-white/5 transition-all duration-300">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              
              {/* Logo Futurista */}
              <Link to="/" className="flex items-center gap-3 group">
                <div className="w-10 h-10 bg-gradient-to-tr from-blue-600 to-purple-600 rounded-xl flex items-center justify-center text-white font-bold shadow-lg shadow-blue-500/20 group-hover:rotate-12 transition-transform duration-300">
                  CF
                </div>
                <span className="text-xl font-bold tracking-tight text-white group-hover:text-blue-200 transition-colors">
                  CitaFácil
                </span>
              </Link>
              
              {/* Enlaces de Navegación */}
              <div className="flex items-center gap-6">
                <Link 
                  to="/" 
                  className="text-sm font-medium text-zinc-400 hover:text-white transition-colors relative group"
                >
                  Cliente
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-500 transition-all group-hover:w-full"></span>
                </Link>
                
                <Link 
                  to="/admin" 
                  className="px-5 py-2.5 text-sm font-bold bg-white text-black rounded-full hover:bg-zinc-200 transition-all shadow-[0_0_15px_rgba(255,255,255,0.1)] hover:shadow-[0_0_25px_rgba(255,255,255,0.3)] hover:scale-105"
                >
                  Soy el Dueño
                </Link>
              </div>

            </div>
          </div>
        </nav>

        {/* Contenido Principal con Padding Top para compensar la navbar fija */}
        <div className="pt-24 pb-12">
          <Routes>
            <Route path="/" element={<Booking />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/login" element={<Login />} />
            {/* Nuevas rutas de recuperación de contraseña */}
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/update-password" element={<UpdatePassword />} />
          </Routes>
        </div>

      </div>
    </BrowserRouter>
  );
}

export default App;