import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';

export default function UpdatePassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Verificar que realmente venimos de un enlace de recuperación válido
    const checkHash = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      // Si llegamos aquí y no hay sesión temporal, mandamos al login
      if (!session && !window.location.hash.includes('recovery')) {
        navigate('/login');
      }
    };
    checkHash();
  }, [navigate]);

  const handleUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);

    // Actualizamos la contraseña del usuario autenticado por el token del email
    const { error } = await supabase.auth.updateUser({
      password: password
    });

    setLoading(false);

    if (error) {
      alert("❌ Error: " + error.message);
    } else {
      alert("✅ Contraseña actualizada correctamente.");
      navigate('/admin'); // Lo mandamos directo al dashboard
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-600/20 rounded-full blur-[100px] -z-10 animate-pulse" />
      
      <div className="w-full max-w-md bg-zinc-900/50 backdrop-blur-xl border border-zinc-800 rounded-3xl p-8 shadow-2xl relative">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Nueva Contraseña</h2>
          <p className="text-gray-400 text-sm">Crea una nueva contraseña segura para tu cuenta.</p>
        </div>
        
        <form onSubmit={handleUpdate} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300 ml-1">Nueva Contraseña</label>
            <input 
              type="password" required minLength="6"
              className="w-full bg-zinc-950/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
              placeholder="Mínimo 6 caracteres"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button 
            type="submit" disabled={loading}
            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3.5 rounded-xl font-bold text-lg hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all disabled:opacity-50"
          >
            {loading ? 'Actualizando...' : 'Guardar y entrar'}
          </button>
        </form>
      </div>
    </div>
  );
}