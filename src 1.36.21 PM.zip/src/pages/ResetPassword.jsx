import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useNavigate, Link } from 'react-router-dom';

export default function ResetPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    // Enviamos el correo con el enlace de recuperación
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: 'http://localhost:5173/update-password', // A donde regresará después de hacer clic en el correo
    });

    setLoading(false);

    if (error) {
      setMessage("❌ Error: " + error.message);
    } else {
      setMessage("✅ ¡Correo enviado! Revisa tu bandeja de entrada o spam.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px] -z-10 animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-[100px] -z-10" />

      <div className="w-full max-w-md bg-zinc-900/50 backdrop-blur-xl border border-zinc-800 rounded-3xl p-8 shadow-2xl relative">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Recuperar Acceso</h2>
          <p className="text-gray-400 text-sm">Ingresa tu correo y te enviaremos un enlace para restablecer tu contraseña.</p>
        </div>
        
        <form onSubmit={handleReset} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300 ml-1">Email Corporativo</label>
            <input 
              type="email" required
              className="w-full bg-zinc-950/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all placeholder-zinc-600"
              placeholder="admin@citafacil.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <button 
            type="submit" disabled={loading}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3.5 rounded-xl font-bold text-lg hover:shadow-[0_0_20px_rgba(79,70,229,0.4)] transition-all disabled:opacity-50"
          >
            {loading ? 'Enviando...' : 'Enviar enlace'}
          </button>
        </form>

        {message && (
          <div className="mt-4 p-4 bg-zinc-950/80 border border-zinc-800 rounded-xl text-sm text-center text-white">
            {message}
          </div>
        )}

        <div className="mt-6 text-center">
          <Link to="/login" className="text-sm text-blue-400 hover:text-blue-300 transition-colors">
            Volver al inicio de sesión
          </Link>
        </div>
      </div>
    </div>
  );
}