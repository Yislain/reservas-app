import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useNavigate, Link } from 'react-router-dom';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      alert("Error: " + error.message);
      setLoading(false);
      return;
    }

    // Consultar el rol inmediatamente después de loguear
    const { data: profile } = await supabase
      .from('perfiles')
      .select('role')
      .eq('id', data.user.id)
      .single();

    if (profile?.role === 'admin') {
      navigate('/admin');
    } else {
      navigate('/mis-citas');
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 mt-10">
      <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-3xl shadow-2xl">
        <h2 className="text-3xl font-bold text-white mb-6 text-center">Bienvenido</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <input 
            type="email" placeholder="Correo" required
            className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white"
            value={email} onChange={(e) => setEmail(e.target.value)}
          />
          <input 
            type="password" placeholder="Contraseña" required
            className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white"
            value={password} onChange={(e) => setPassword(e.target.value)}
          />
          <button disabled={loading} className="w-full py-4 bg-blue-600 rounded-xl font-bold hover:bg-blue-700 transition">
            {loading ? 'Entrando...' : 'Iniciar Sesión'}
          </button>
        </form>
        <p className="mt-6 text-center text-zinc-400 text-sm">
          ¿No tienes cuenta? <Link to="/registro" className="text-blue-400 font-bold">Regístrate aquí</Link>
        </p>
      </div>
    </div>
  );
}