import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function Admin() {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, pending: 0, completed: 0 });

  useEffect(() => {
    checkAdmin();
  }, []);

  async function checkAdmin() {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return navigate('/login');

    const { data: profile } = await supabase.from('perfiles').select('role').eq('id', session.user.id).single();
    if (profile?.role !== 'admin') return navigate('/mis-citas');

    fetchAppointments();
  }

  async function fetchAppointments() {
    const { data, error } = await supabase.from('appointments').select('*').order('appointment_date', { ascending: true });
    if (!error) {
      setAppointments(data);
      setStats({
        total: data.length,
        pending: data.filter(a => a.status === 'pending').length,
        completed: data.filter(a => a.status === 'confirmed').length
      });
    }
    setLoading(false);
  }

  const handleUpdateStatus = async (id, newStatus) => {
    const { error } = await supabase.from('appointments').update({ status: newStatus }).eq('id', id);
    if (!error) fetchAppointments();
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <div className="flex justify-between items-end mb-10">
        <div>
          <h1 className="text-5xl font-black text-white tracking-tighter">Panel Maestro</h1>
          <p className="text-zinc-500 mt-2">Control total de las reservas del sistema.</p>
        </div>
        <div className="flex gap-4">
          <StatCard title="Total" value={stats.total} color="text-blue-500" />
          <StatCard title="Pendientes" value={stats.pending} color="text-yellow-500" />
        </div>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-zinc-800/50 text-zinc-400 text-xs uppercase tracking-widest font-bold">
              <th className="p-6">Cliente</th>
              <th className="p-6">Fecha y Hora</th>
              <th className="p-6">Estado</th>
              <th className="p-6 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {appointments.map(cita => (
              <tr key={cita.id} className="hover:bg-zinc-800/30 transition-colors group">
                <td className="p-6">
                  <div className="text-white font-bold">{cita.customer_name}</div>
                  <div className="text-zinc-500 text-sm">{cita.customer_email}</div>
                </td>
                <td className="p-6">
                  <div className="text-white">{cita.appointment_date}</div>
                  <div className="text-blue-400 font-mono text-xs">{cita.appointment_time}</div>
                </td>
                <td className="p-6">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                    cita.status === 'pending' ? 'bg-yellow-500/10 text-yellow-500' : 'bg-green-500/10 text-green-500'
                  }`}>
                    {cita.status}
                  </span>
                </td>
                <td className="p-6">
                  <div className="flex justify-center gap-2">
                    <button onClick={() => handleUpdateStatus(cita.id, 'confirmed')} className="p-2 bg-green-500/10 text-green-500 rounded-lg hover:bg-green-500 hover:text-white transition-all">✓</button>
                    <button onClick={() => handleUpdateStatus(cita.id, 'cancelled')} className="p-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-all">✕</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatCard({ title, value, color }) {
  return (
    <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl min-w-[140px]">
      <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{title}</p>
      <p className={`text-3xl font-black ${color}`}>{value}</p>
    </div>
  );
}