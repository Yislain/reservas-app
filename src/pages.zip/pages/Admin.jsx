import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function Admin() {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, pending: 0, earnings: 0 });

  useEffect(() => {
    // Verificamos si hay sesión activa antes de cargar los datos
    const checkAuthAndFetch = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate('/login'); // Expulsar si no está logueado
        return;
      }

      // Si está logueado, cargamos las citas
      const { data, error } = await supabase
        .from('appointments')
        .select('*')
        .order('appointment_date', { ascending: true }); // Ordenadas por fecha

      if (!error && data) {
        setAppointments(data);
        const pending = data.filter(a => a.status === 'pending').length;
        setStats({
          total: data.length,
          pending: pending,
          earnings: data.length * 50 // Asumiendo $50 por cita
        });
      }
      setLoading(false);
    };

    checkAuthAndFetch();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  const handleCancel = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar esta cita?')) return;
    const { error } = await supabase.from('appointments').delete().eq('id', id);
    if (!error) {
      // Actualizamos la tabla en pantalla sin recargar la página
      setAppointments(appointments.filter(cita => cita.id !== id));
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-zinc-400">Verificando acceso seguro...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-extrabold text-white tracking-tight">Dashboard</h1>
          <p className="text-zinc-400 mt-1">Gestión de reservas.</p>
        </div>
        <button 
          onClick={handleLogout}
          className="bg-red-500/10 text-red-400 border border-red-500/20 px-6 py-2.5 rounded-xl font-bold hover:bg-red-500 hover:text-white transition-all shadow-lg"
        >
          Cerrar Sesión
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <StatCard title="Total Citas" value={stats.total} icon="📅" color="text-blue-400" />
        <StatCard title="Pendientes" value={stats.pending} icon="⏳" color="text-yellow-400" />
        <StatCard title="Ingresos Est." value={`$${stats.earnings}`} icon="💰" color="text-green-400" />
      </div>

      <div className="bg-zinc-900/40 backdrop-blur-xl border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl">
        <div className="p-6 border-b border-zinc-800">
          <h2 className="text-xl font-bold text-white">Lista de Reservas</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-950/50 text-zinc-400 text-xs uppercase tracking-widest font-bold">
                <th className="p-5 border-b border-zinc-800">Cliente</th>
                <th className="p-5 border-b border-zinc-800">Contacto</th>
                <th className="p-5 border-b border-zinc-800">Fecha y Hora</th>
                <th className="p-5 border-b border-zinc-800 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
              {appointments.length === 0 ? (
                <tr>
                  <td colSpan="4" className="p-8 text-center text-zinc-500">No hay citas registradas aún.</td>
                </tr>
              ) : (
                appointments.map((cita) => (
                  <tr key={cita.id} className="hover:bg-white/5 transition-colors group">
                    <td className="p-5 font-bold text-white">{cita.client_name}</td>
                    <td className="p-5">
                      <div className="text-sm text-zinc-300">{cita.customer_email}</div>
                      <div className="text-xs text-zinc-500">{cita.client_phone}</div>
                    </td>
                    <td className="p-5">
                      <div className="text-white text-sm font-medium">{cita.appointment_date}</div>
                      <div className="text-blue-500 text-xs font-bold">{cita.appointment_time}</div>
                    </td>
                    <td className="p-5 text-center">
                      <button 
                        onClick={() => handleCancel(cita.id)} 
                        className="p-2.5 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition-all border border-red-500/20"
                        title="Cancelar cita"
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, color }) {
  return (
    <div className="bg-zinc-900/60 backdrop-blur-md border border-zinc-800 p-8 rounded-3xl flex items-center justify-between shadow-xl">
      <div>
        <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest">{title}</p>
        <p className={`text-4xl font-black mt-2 ${color}`}>{value}</p>
      </div>
      <div className="text-4xl bg-zinc-800/50 p-4 rounded-2xl grayscale">{icon}</div>
    </div>
  );
}