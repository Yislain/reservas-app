import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export default function ClientDashboard() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchMyAppointments() {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data, error } = await supabase
        .from('appointments')
        .select('*')
        .eq('customer_email', user.email) // Filtramos por su correo
        .order('appointment_date', { ascending: false });

      if (!error) setAppointments(data);
      setLoading(false);
    }
    fetchMyAppointments();
  }, []);

  return (
    <div className="max-w-5xl mx-auto px-4">
      <h1 className="text-3xl font-bold text-white mb-8">Mis Citas Reservadas</h1>
      
      <div className="grid gap-4">
        {loading ? (
          <p className="text-zinc-500">Cargando tus citas...</p>
        ) : appointments.length === 0 ? (
          <div className="bg-zinc-900 p-8 rounded-2xl border border-zinc-800 text-center">
            <p className="text-zinc-400">Aún no tienes citas programadas.</p>
          </div>
        ) : (
          appointments.map(cita => (
            <div key={cita.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl flex justify-between items-center">
              <div>
                <p className="text-blue-400 font-bold text-sm uppercase tracking-widest">{cita.appointment_time}</p>
                <h3 className="text-xl text-white font-bold">{cita.appointment_date}</h3>
                <p className="text-zinc-500 text-sm">Estado: <span className="text-yellow-500">{cita.status}</span></p>
              </div>
              <div className="text-right">
                <span className="text-zinc-400 text-xs">ID de Reserva: #{cita.id.slice(0, 8)}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}