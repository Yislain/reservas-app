import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

const TIME_SLOTS = [
  "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "12:00", "12:30", "13:00", "13:30", "15:00", "15:30",
  "16:00", "16:30", "17:00", "17:30", "18:00"
];

export default function Booking() {
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState('');
  const [takenSlots, setTakenSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '', // CAMPO AÑADIDO: Teléfono obligatorio
    date: '',
    time: ''
  });

  useEffect(() => {
    async function fetchServices() {
      const { data, error } = await supabase.from('services').select('*');
      if (!error && data) {
        setServices(data);
        if (data.length > 0) setSelectedService(data[0].id);
      }
      setLoading(false);
    }
    fetchServices();
  }, []);

  useEffect(() => {
    if (formData.date) checkAvailability(formData.date);
  }, [formData.date]);

  async function checkAvailability(date) {
    const { data } = await supabase
      .from('appointments')
      .select('appointment_time') // Mapeado a Supabase
      .eq('appointment_date', date); // Mapeado a Supabase
      
    if (data) {
      setTakenSlots(data.map(app => app.appointment_time));
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    // Mapeo exacto de las columnas con la estructura de tu tabla
    const { error } = await supabase.from('appointments').insert([
      {
        client_name: formData.name,       
        client_phone: formData.phone,      
        customer_email: formData.email,    
        service_id: selectedService || null,
        appointment_date: formData.date,   
        appointment_time: formData.time,   
        status: 'pending'
      }
    ]);

    setSubmitting(false);

    if (error) {
      alert('❌ Error al reservar: ' + error.message);
      console.error(error);
    } else {
      alert('✅ ¡Tu cita ha sido reservada con éxito!');
      setFormData({ name: '', email: '', phone: '', date: '', time: '' });
      setTakenSlots([]);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-white">Cargando disponibilidad...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight mb-4">
          Reserva tu <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Cita</span>
        </h1>
        <p className="text-zinc-400">Selecciona el día y la hora que mejor te acomode.</p>
      </div>

      <div className="bg-zinc-900/50 backdrop-blur-xl border border-zinc-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-600/20 rounded-full blur-[80px] -z-10" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-600/20 rounded-full blur-[80px] -z-10" />

        <form onSubmit={handleSubmit} className="space-y-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300 ml-1">Nombre Completo</label>
              <input 
                type="text" required
                className="w-full bg-zinc-950/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                placeholder="Ej. Juan Pérez"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300 ml-1">Correo Electrónico</label>
              <input 
                type="email" required
                className="w-full bg-zinc-950/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                placeholder="tu@correo.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300 ml-1">Teléfono Móvil</label>
              <input 
                type="tel" required
                className="w-full bg-zinc-950/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                placeholder="555-123-4567"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300 ml-1">Fecha</label>
              <input 
                type="date" required
                min={new Date().toISOString().split('T')[0]} 
                className="w-full bg-zinc-950/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all [color-scheme:dark]"
                value={formData.date}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
              />
            </div>
          </div>

          {/* Selector de Servicio Opcional (Si tienes servicios cargados) */}
          {services.length > 0 && (
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300 ml-1">Servicio</label>
              <select
                className="w-full bg-zinc-950/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all appearance-none"
                value={selectedService}
                onChange={(e) => setSelectedService(e.target.value)}
              >
                {services.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          )}

          {formData.date && (
            <div className="space-y-4 pt-4 border-t border-zinc-800">
              <label className="text-sm font-medium text-zinc-300 ml-1">Horarios Disponibles</label>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                {TIME_SLOTS.map((time) => {
                  const isTaken = takenSlots.includes(time);
                  const isSelected = formData.time === time;
                  
                  return (
                    <button 
                      key={time} type="button" disabled={isTaken}
                      onClick={() => setFormData({...formData, time})}
                      className={`
                        relative py-2 text-sm font-medium rounded-xl transition-all duration-300
                        ${isTaken 
                          ? 'bg-zinc-900 text-zinc-700 cursor-not-allowed border border-transparent' 
                          : isSelected
                            ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.5)] scale-105 border border-blue-400'
                            : 'bg-zinc-950/50 text-gray-300 border border-zinc-700 hover:border-blue-500 hover:text-blue-400'
                        }
                      `}
                    >
                      {time}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <button 
            type="submit" 
            disabled={!formData.time || submitting}
            className={`w-full py-4 rounded-xl font-bold text-lg tracking-wide transition-all duration-300 shadow-lg mt-8
              ${formData.time && !submitting
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:shadow-[0_0_30px_rgba(79,70,229,0.4)] hover:scale-[1.02]' 
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
              }
            `}
          >
            {submitting ? 'Procesando reserva...' : 'Confirmar Cita'}
          </button>
        </form>
      </div>
    </div>
  );
}