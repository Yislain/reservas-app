import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export default function Booking() {
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', date: '', time: '' });

  useEffect(() => {
    // Si hay sesión, autocompletamos el email
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) setFormData(prev => ({ ...prev, email: user.email }));
    });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    const { error } = await supabase.from('appointments').insert([
      { ...formData, status: 'pending' }
    ]);

    if (error) alert(error.message);
    else {
      alert("¡Cita reservada con éxito!");
      setFormData({ ...formData, time: '' });
    }
    setSubmitting(false);
  };

  return (
    <div className="max-w-xl mx-auto px-6 py-10">
      <div className="bg-zinc-900 border border-zinc-800 p-10 rounded-[3rem] shadow-2xl">
        <h2 className="text-3xl font-black text-white mb-8">Reserva tu espacio</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <input 
            type="text" placeholder="Nombre completo" required
            className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 text-white"
            value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
          />
          <input 
            type="email" placeholder="Email" required disabled={!!formData.email}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 text-white opacity-60"
            value={formData.email}
          />
          <input 
            type="date" required
            className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 text-white"
            value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})}
          />
          {/* Aquí iría tu selector de horas (TIME_SLOTS) que ya tenías */}
          <button disabled={submitting} className="w-full py-5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-purple-600/20 active:scale-95 transition-all">
            {submitting ? 'Procesando...' : 'Confirmar ahora'}
          </button>
        </form>
      </div>
    </div>
  );
}